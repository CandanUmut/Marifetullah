# Marifa App (Flutter)

An interactive learning app to cultivate ma'rifatullah (knowing God) using:
- The 99 Names of Allah (EN/TR, extendable via JSON assets)
- Research points (EN/TR)
- Local progress tracking with SharedPreferences
- Clean, responsive UI (works on mobile and web)

## Quick Start
```bash
flutter pub get
flutter run -d chrome   # for web
# or
flutter run              # for mobile/simulator
```

## Add / Update Content
Edit the JSON assets:
- `assets/names_en.json`, `assets/names_tr.json`
- `assets/research_en.json`, `assets/research_tr.json`

Each name entry:
```json
{
  "index": 1,
  "arabic": "الله",
  "name_en": "Allah",
  "name_tr": "Allah",
  "meaning_en": "The proper name of God; the One worthy of all worship",
  "meaning_tr": "Yegâne ilâh; bütün ibadete tek layık olan",
  "tefekkur_en": "Contemplate the absolute uniqueness and perfection of God.",
  "tefekkur_tr": "Allah’ın biricik ve kemal sahibi oluşunu tefekkür et.",
  "practice_en": "Renew your declaration of faith sincerely.",
  "practice_tr": "İhlâsla kelime-i tevhidi yenile."
}
```
