class PrefKeys {
  static const String lang = 'app_lang'; // 'en' or 'tr'
  static const String reviewedNames = 'reviewed_names'; // List<int> JSON
  static const String completedPractices = 'completed_practices';
}
