import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'utils/app_theme.dart';
import 'providers/locale_provider.dart';
import 'providers/names_provider.dart';
import 'providers/research_provider.dart';
import 'services/storage_service.dart';
import 'pages/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  runApp(const MarifaApp());
}

class MarifaApp extends StatelessWidget {
  const MarifaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LocaleProvider()),
        ChangeNotifierProvider(create: (_) => NamesProvider()),
        ChangeNotifierProvider(create: (_) => ResearchProvider()),
      ],
      child: Consumer<LocaleProvider>(
        builder: (context, lp, _) {
          return MaterialApp(
            title: 'Marifa App',
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: ThemeMode.system,
            home: const HomeShell(),
          );
        },
      ),
    );
  }
}
