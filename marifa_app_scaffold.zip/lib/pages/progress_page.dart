import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/names_provider.dart';

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<NamesProvider>();
    final p = prov.progress();
    final percent = (p * 100).toStringAsFixed(0);
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 140, width: 140,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(value: p, strokeWidth: 10),
                Text('$percent%', style: Theme.of(context).textTheme.headlineMedium),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text('Names reviewed: ${prov.reviewed.length} / ${prov.items.length}')
        ],
      ),
    );
  }
}
