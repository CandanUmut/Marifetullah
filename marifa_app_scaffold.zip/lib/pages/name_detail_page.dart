import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/locale_provider.dart';
import '../providers/names_provider.dart';

class NameDetailPage extends StatelessWidget {
  final int entryIndex;
  const NameDetailPage({super.key, required this.entryIndex});

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LocaleProvider>().lang;
    final prov = context.watch<NamesProvider>();
    final n = prov.items.firstWhere((e) => e.index == entryIndex);
    final title = lang == 'tr' ? n.nameTr : n.nameEn;
    final meaning = lang == 'tr' ? n.meaningTr : n.meaningEn;
    final taf = lang == 'tr' ? n.tafakkurTr : n.tafakkurEn;
    final prac = lang == 'tr' ? n.practiceTr : n.practiceEn;
    final reviewed = prov.isReviewed(n.index);

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(meaning, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Text('Tefekkür / Reflection', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(taf),
            const SizedBox(height: 12),
            Text('Günlük Pratik / Daily Practice', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(prac),
            const SizedBox(height: 24),
            FilledButton.icon(
              icon: Icon(reviewed ? Icons.check : Icons.flag),
              label: Text(reviewed ? 'Marked as Reviewed' : 'Mark as Reviewed'),
              onPressed: () => context.read<NamesProvider>().toggleReviewed(n.index),
            ),
          ],
        ),
      ),
    );
  }
}
