import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/locale_provider.dart';
import '../services/storage_service.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<LocaleProvider>();
    return ListView(
      children: [
        const ListTile(title: Text('Language / Dil')),
        RadioListTile(
          value: 'en', groupValue: prov.lang, title: const Text('English'),
          onChanged: (v) => context.read<LocaleProvider>().setLang(v as String),
        ),
        RadioListTile(
          value: 'tr', groupValue: prov.lang, title: const Text('Türkçe'),
          onChanged: (v) => context.read<LocaleProvider>().setLang(v as String),
        ),
        const Divider(),
        ListTile(
          title: const Text('Reset Progress'),
          trailing: const Icon(Icons.delete_outline),
          onTap: () async {
            await StorageService.resetAll();
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Progress reset.')));
            }
          },
        ),
      ],
    );
  }
}
