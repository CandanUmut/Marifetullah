import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/research_provider.dart';
import 'research_detail_page.dart';

class ResearchListPage extends StatelessWidget {
  const ResearchListPage({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<ResearchProvider>();
    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      itemCount: prov.sections.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (ctx, i) {
        final s = prov.sections[i];
        return ListTile(
          title: Text(s.title),
          subtitle: Text(s.summary),
          onTap: () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => ResearchDetailPage(sectionIndex: i))),
        );
      },
    );
  }
}
