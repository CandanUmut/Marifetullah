import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/locale_provider.dart';
import '../providers/names_provider.dart';
import 'name_detail_page.dart';

class NamesListPage extends StatefulWidget {
  const NamesListPage({super.key});
  @override
  State<NamesListPage> createState() => _NamesListPageState();
}

class _NamesListPageState extends State<NamesListPage> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LocaleProvider>().lang;
    final prov = context.watch<NamesProvider>();
    final items = prov.items.where((n) {
      final t = lang == 'tr' ? n.nameTr : n.nameEn;
      final m = lang == 'tr' ? n.meaningTr : n.meaningEn;
      final q = _q.toLowerCase();
      return t.toLowerCase().contains(q) || m.toLowerCase().contains(q);
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search...'),
            onChanged: (v) => setState(() => _q = v),
          ),
        ),
        Expanded(
          child: ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (ctx, i) {
              final n = items[i];
              final title = lang == 'tr' ? n.nameTr : n.nameEn;
              final subtitle = lang == 'tr' ? n.meaningTr : n.meaningEn;
              final reviewed = prov.isReviewed(n.index);
              return ListTile(
                title: Text('${n.index}. $title'),
                subtitle: Text(subtitle),
                trailing: Icon(reviewed ? Icons.check_circle : Icons.circle_outlined, color: reviewed ? Colors.green : null),
                onTap: () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => NameDetailPage(entryIndex: n.index))),
              );
            },
          ),
        ),
      ],
    );
  }
}
