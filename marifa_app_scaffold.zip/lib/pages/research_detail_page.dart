import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/research_provider.dart';

class ResearchDetailPage extends StatelessWidget {
  final int sectionIndex;
  const ResearchDetailPage({super.key, required this.sectionIndex});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<ResearchProvider>();
    final s = prov.sections[sectionIndex];
    return Scaffold(
      appBar: AppBar(title: Text(s.title)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(s.summary, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            ...s.bullets.map((b) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('• '),
                  Expanded(child: Text(b)),
                ],
              ),
            ))
          ],
        ),
      ),
    );
  }
}
