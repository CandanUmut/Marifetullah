class ResearchSection {
  final String id;
  final String title;
  final String summary;
  final List<String> bullets;

  ResearchSection({required this.id, required this.title, required this.summary, required this.bullets});

  factory ResearchSection.fromJson(Map<String, dynamic> j) => ResearchSection(
    id: j['id'] ?? '',
    title: j['title'] ?? '',
    summary: j['summary'] ?? '',
    bullets: (j['bullets'] as List?)?.map((e) => e.toString()).toList() ?? const [],
  );
}
