class NameEntry {
  final int index;
  final String arabic;
  final String nameEn;
  final String nameTr;
  final String meaningEn;
  final String meaningTr;
  final String tafakkurEn;
  final String tafakkurTr;
  final String practiceEn;
  final String practiceTr;

  NameEntry({
    required this.index,
    required this.arabic,
    required this.nameEn,
    required this.nameTr,
    required this.meaningEn,
    required this.meaningTr,
    required this.tafakkurEn,
    required this.tafakkurTr,
    required this.practiceEn,
    required this.practiceTr,
  });

  factory NameEntry.fromJson(Map<String, dynamic> j) => NameEntry(
    index: j['index'] ?? 0,
    arabic: j['arabic'] ?? '',
    nameEn: j['name_en'] ?? '',
    nameTr: j['name_tr'] ?? '',
    meaningEn: j['meaning_en'] ?? '',
    meaningTr: j['meaning_tr'] ?? '',
    tafakkurEn: j['tefekkur_en'] ?? '',
    tafakkurTr: j['tefekkur_tr'] ?? '',
    practiceEn: j['practice_en'] ?? '',
    practiceTr: j['practice_tr'] ?? '',
  );
}
