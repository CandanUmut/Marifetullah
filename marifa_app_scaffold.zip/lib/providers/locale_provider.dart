import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class LocaleProvider extends ChangeNotifier {
  String _lang = 'en';
  String get lang => _lang;

  LocaleProvider() {
    _lang = StorageService.getLang();
  }

  Future<void> setLang(String value) async {
    _lang = value;
    await StorageService.setLang(value);
    notifyListeners();
  }
}
