import 'package:flutter/material.dart';
import '../models/research_section.dart';
import '../services/data_service.dart';

class ResearchProvider extends ChangeNotifier {
  List<ResearchSection> _sections = [];
  List<ResearchSection> get sections => _sections;

  Future<void> load(String lang) async {
    _sections = await DataService.loadResearch(lang);
    notifyListeners();
  }
}
