import 'package:flutter/material.dart';
import '../models/name_entry.dart';
import '../services/data_service.dart';
import '../services/storage_service.dart';

class NamesProvider extends ChangeNotifier {
  List<NameEntry> _all = [];
  List<NameEntry> get items => _all;
  Set<int> _reviewed = {};
  Set<int> get reviewed => _reviewed;

  Future<void> load(String lang) async {
    _all = await DataService.loadNames(lang);
    _reviewed = StorageService.getReviewedNames();
    notifyListeners();
  }

  bool isReviewed(int index) => _reviewed.contains(index);

  Future<void> toggleReviewed(int index) async {
    if (_reviewed.contains(index)) {
      _reviewed.remove(index);
    } else {
      _reviewed.add(index);
    }
    await StorageService.setReviewedNames(_reviewed);
    notifyListeners();
  }

  double progress() {
    if (_all.isEmpty) return 0;
    return _reviewed.length / _all.length;
  }
}
