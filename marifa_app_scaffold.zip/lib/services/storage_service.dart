import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

class StorageService {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static String getLang() => _prefs.getString(PrefKeys.lang) ?? 'en';
  static Future<void> setLang(String lang) => _prefs.setString(PrefKeys.lang, lang);

  static Set<int> getReviewedNames() {
    final str = _prefs.getString(PrefKeys.reviewedNames);
    if (str == null) return <int>{};
    final list = (jsonDecode(str) as List).map((e) => e as int).toSet();
    return list;
  }

  static Future<void> setReviewedNames(Set<int> items) async {
    final str = jsonEncode(items.toList());
    await _prefs.setString(PrefKeys.reviewedNames, str);
  }

  static Future<void> resetAll() async {
    await _prefs.remove(PrefKeys.reviewedNames);
  }
}
