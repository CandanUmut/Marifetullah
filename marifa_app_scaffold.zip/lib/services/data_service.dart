import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/name_entry.dart';
import '../models/research_section.dart';

class DataService {
  static Future<List<NameEntry>> loadNames(String lang) async {
    final path = lang == 'tr' ? 'assets/names_tr.json' : 'assets/names_en.json';
    final txt = await rootBundle.loadString(path);
    final list = jsonDecode(txt) as List;
    return list.map((e) => NameEntry.fromJson(e)).toList();
  }

  static Future<List<ResearchSection>> loadResearch(String lang) async {
    final path = lang == 'tr' ? 'assets/research_tr.json' : 'assets/research_en.json';
    final txt = await rootBundle.loadString(path);
    final obj = jsonDecode(txt) as Map<String, dynamic>;
    final sections = obj['sections'] as List? ?? [];
    return sections.map((e) => ResearchSection.fromJson(e)).toList();
  }
}
